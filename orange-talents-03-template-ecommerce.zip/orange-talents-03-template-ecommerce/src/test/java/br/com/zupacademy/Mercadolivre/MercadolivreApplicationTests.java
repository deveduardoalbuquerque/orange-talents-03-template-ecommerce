package br.com.zupacademy.Mercadolivre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MercadolivreApplicationTests {

	@Test
	void contextLoads() {
	}

}

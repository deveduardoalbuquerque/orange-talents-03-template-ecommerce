package br.com.zupacademy.Mercadolivre.validacao;

public interface Groups {

    interface Categoria{};
}
